# Telecom-Customer-Churn-Data-Analysis

# BUSINEES OBJECTIVE
The Telecom Company needs assistance in performing some quantitative analysis on the provided dataset and generate some relevant insights. This should guide the Company to first understand what factors are potentially causing churn and by taking what actions can the churn be minimized.

# APPROACH
1) A good starting point can be by doing the analysis on how the Churn and non-Churn profiles are showing the results when compared with the weeks that the customers has been active
2) Another approach can be by observing the insights on how the Churn and non-Churn profiles are showing the results when compared with the various relevant attributes like average talk time, monthly bill, contract renewed etc
